CONCURSO BÍBLICO V13.7 CORRIGIDO

Correções aplicadas:
- Banco completo de 2.271 perguntas carregado a partir de questionBank.js.
- Fases criadas automaticamente no navegador:
  Fase 1 a Fase 5 com 450 perguntas cada.
  Desafio Final com 21 perguntas.
- Som aumentado para melhor volume no computador.
- Ao esgotar o tempo, o jogo pula automaticamente para a próxima pergunta sem mostrar a resposta.
- Mantidos cronômetro de 3, 6, 9 ou 12 segundos e trilha de tensão.

Para publicar no GitHub:
1. Envie todos os arquivos desta pasta para a raiz do repositório.
2. Substitua os arquivos antigos.
3. Teste: https://jaimeleite2012-sketch.github.io/show-biblico-ibc/?v=13.7
